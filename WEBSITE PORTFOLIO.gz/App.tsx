import React, { useState } from 'react';
import kenPhotoUrl from 'container:///mnt/data/src/assets/424cb3c2f1cd84ae-ken_professional_photo.jpg';
import { ArrowUpRight, BadgeCheck, CalendarCheck, CheckCircle2, Headset, Mail, MapPin, MessageCircle, PhoneCall, ShieldCheck, Sparkles, Star, Users, Wrench } from 'lucide-react';

const shellStyle = { boxSizing: 'border-box' as const, paddingTop: 'var(--safe-area-inset-top)' };

const services = [
  { icon: '◧', title: 'Admin Support', desc: 'Email and calendar management, data entry, CRM cleanup, meeting minutes, follow-ups, travel booking, and SOPs that keep the day running without friction.', points: ['Inbox & calendar control', 'Clean CRM records', 'SOPs & documentation'] },
  { icon: '◐', title: 'Appointment Setting', desc: 'High-volume outbound calling that turns cold leads into confirmed jobs. Clear scripts, respectful follow-up, and calendars that stay full.', points: ['5–10 appointments / week', '200–250 leads / week', 'Confirmations & reminders'] },
  { icon: '⬢', title: 'Customer Support', desc: 'Calm, accurate support for financial and mortgage accounts — with the QA discipline that comes from handling 90–130 calls a day.', points: ['Financial & mortgage support', 'QA-ready documentation', 'Empathy under pressure'] },
  { icon: '◎', title: 'Recruitment Support', desc: 'Interviews and screening for independent cleaning contractors, plus organized candidate notes so hiring decisions move faster.', points: ['Contractor interviews', 'Screening & shortlists', 'Structured follow-up'] },
  { icon: '⬣', title: 'Social Media Management', desc: 'Ads and posts that keep a local cleaning brand visible, plus management for Facebook, Indeed, and your company website.', points: ['Ad posting & scheduling', 'Page & profile care', 'Consistent local presence'] },
];

const tools = [
  { name: 'Salesforce', cat: 'CRM & Operations' }, { name: 'Zendesk', cat: 'CRM & Operations' }, { name: 'Avaya', cat: 'Voice' }, { name: 'IVR', cat: 'Voice' }, { name: 'Google Voice', cat: 'Voice' },
  { name: 'Microsoft Teams', cat: 'Communication' }, { name: 'Google Meet', cat: 'Communication' }, { name: 'Zoom', cat: 'Communication' },
  { name: 'Google Sheets', cat: 'Productivity' }, { name: 'Google Calendar', cat: 'Productivity' }, { name: 'Facebook', cat: 'Marketing' }, { name: 'Indeed', cat: 'Marketing' },
];

const experiences = [
  {
    role: 'Virtual Assistant / Administrative Assistant',
    company: 'Divine Shine & Property Cleaners',
    meta: 'US cleaning company · Greater Austin, Texas · Remote',
    summary: 'The operational right hand for a growing cleaning business — inbox, calendar, hiring, systems, and social presence handled in one dependable workflow.',
    points: ['Managed email, calendar, travel booking, and itineraries', 'Kept CRM records clean with accurate data entry and follow-ups', 'Wrote meeting minutes, SOPs, and business documents', 'Posted ads and managed Facebook, Indeed, and the company website', 'Conducted interviews for independent cleaning contractors'],
  },
  {
    role: 'Cold Caller / Appointment Setter',
    company: 'US-Based Cleaning Company',
    meta: 'Outbound sales support · Remote',
    summary: 'Turned large lead lists into real bookings with steady, professional outreach and careful follow-through.',
    points: ['Booked 5–10 appointments every week', 'Called 200–250 different leads per week', 'Used Zendesk, Google Voice, Sheets, Meet, Zoom, and Calendar', 'Kept notes clean so no lead slipped through'],
  },
  {
    role: 'Customer Support Representative',
    company: 'BPO · Financial & Mortgage Accounts',
    meta: '3 years · High-volume customer support',
    summary: 'Three years of disciplined, quality-driven support for sensitive financial and mortgage conversations.',
    points: ['Handled 90–130 calls per day', 'Helped customers resolve financial and mortgage concerns', 'Focused on satisfaction and passing QA', 'Used Salesforce, Avaya, IVR, and Microsoft Teams'],
  },
];

const stats = [
  { value: '90–130', label: 'customer calls handled per day' },
  { value: '5–10', label: 'appointments booked every week' },
  { value: '200–250', label: 'cold leads called every week' },
  { value: '3+ years', label: 'in BPO, customer support & virtual assistance' },
];

function SectionHeading({ eyebrow, title, dark = false, center = false, blurb }: { eyebrow: string; title: string; dark?: boolean; center?: boolean; blurb?: string }) {
  return (
    <div className={center ? 'mx-auto max-w-2xl text-center' : 'max-w-2xl'}>
      <p className={`eyebrow ${dark ? 'text-[var(--gold-light)]' : 'text-[var(--gold-dark)]'}`}>{eyebrow}</p>
      <h2 className={`mt-4 text-[clamp(2.1rem,5.5vw,3.4rem)] ${dark ? 'text-white' : 'text-[var(--ink)]'}`}>{title}</h2>
      <div className={`gold-rule mt-6 ${center ? 'gold-rule-center' : ''}`} aria-hidden="true" />
      {blurb ? <p className={`mt-5 text-[15px] leading-relaxed ${dark ? 'text-[#C8CFDB]' : 'text-[var(--muted)]'}`}>{blurb}</p> : null}
    </div>
  );
}

function App() {
  const [service, setService] = useState(0);
  const [toolFilter, setToolFilter] = useState('All tools');
  const [menuOpen, setMenuOpen] = useState(false);
  const filters = ['All tools', 'CRM & Operations', 'Voice', 'Communication', 'Productivity', 'Marketing'];
  const visibleTools = tools.filter((t) => toolFilter === 'All tools' || t.cat === toolFilter);

  return (
    <div data-safe-area-inset-root style={shellStyle} className="min-h-screen bg-[var(--paper)] text-[var(--ink)] overflow-x-clip">
      <header data-safe-area-sticky-top style={{ top: 'var(--safe-area-inset-top)' }} className="sticky z-30 border-b border-[#C6A664]/30 bg-[#0A1628]/95 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3 sm:px-6">
          <a href="#top" className="flex items-center gap-3">
            <span className="grid h-10 w-10 place-items-center rounded-full border border-[#C6A664] bg-[#13294B] text-sm font-extrabold tracking-wide text-[#E8D5A8]">KTC</span>
            <span className="leading-none"><span className="block text-[16px] font-extrabold tracking-tight text-white sm:text-[17px]">KEN TEGIO CADA</span><span className="mt-1 block text-[10px] font-bold uppercase tracking-[.18em] text-[#C6A664]">Virtual Assistant</span></span>
          </a>
          <nav className="hidden items-center gap-6 text-sm font-bold text-white/85 lg:flex">
            <a className="hover:text-[#E8D5A8]" href="#about">About</a><a className="hover:text-[#E8D5A8]" href="#experience">Experience</a><a className="hover:text-[#E8D5A8]" href="#services">Services</a><a className="hover:text-[#E8D5A8]" href="#tools">Tools</a><a className="hover:text-[#E8D5A8]" href="#why">Why Ken Tegio Cada</a>
          </nav>
          <div className="flex items-center gap-2">
            <a href="https://wa.me/639951404758" target="_blank" rel="noopener" className="hidden rounded-full bg-[#C6A664] px-4 py-2.5 text-sm font-extrabold text-[#0A1628] sm:block">WhatsApp Ken Tegio Cada</a>
            <button onClick={() => setMenuOpen(!menuOpen)} aria-expanded={menuOpen} className="rounded-full border border-white/25 px-3 py-2 text-sm font-bold text-white lg:hidden">{menuOpen ? 'Close' : 'Menu'}</button>
          </div>
        </div>
        {menuOpen && <nav className="border-t border-white/10 px-4 py-3 lg:hidden"><div className="grid gap-1 text-sm font-bold text-white"><a onClick={() => setMenuOpen(false)} className="rounded-lg px-2 py-2 hover:bg-[#13294B]" href="#about">About</a><a onClick={() => setMenuOpen(false)} className="rounded-lg px-2 py-2 hover:bg-[#13294B]" href="#experience">Experience</a><a onClick={() => setMenuOpen(false)} className="rounded-lg px-2 py-2 hover:bg-[#13294B]" href="#services">Services</a><a onClick={() => setMenuOpen(false)} className="rounded-lg px-2 py-2 hover:bg-[#13294B]" href="#tools">Tools</a><a onClick={() => setMenuOpen(false)} className="rounded-lg px-2 py-2 hover:bg-[#13294B]" href="#why">Why Ken Tegio Cada</a></div></nav>}
      </header>

      <main id="top">
        {/* HERO — centered, Premium PDF header */}
        <section className="hero-premium relative overflow-hidden text-white">
          <div className="hero-grid absolute inset-0" aria-hidden="true" />
          <div className="absolute left-1/2 top-0 h-72 w-[42rem] max-w-none -translate-x-1/2 rounded-full bg-[#C6A664]/10 blur-3xl" aria-hidden="true" />
          <div className="relative mx-auto max-w-6xl px-4 pb-14 pt-12 text-center sm:px-6 sm:pt-16 lg:pb-16">
            <div className="flex flex-wrap items-center justify-center gap-2">
              <span className="inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/10 px-3 py-1.5 text-xs font-bold"><span className="h-2 w-2 rounded-full bg-[#0E9A8B]" /> Available for US clients</span>
              <span className="inline-flex items-center gap-1.5 rounded-full bg-[#C6A664] px-3 py-1.5 text-xs font-extrabold text-[#0A1628]"><MapPin size={13} /> Philippines · Remote</span>
            </div>

            <div className="mx-auto mt-9 w-fit rounded-full border-2 border-[#C6A664] p-2 shadow-[0_0_0_6px_rgba(198,166,100,0.12),0_24px_60px_rgba(0,0,0,0.45)]">
              <img src={kenPhotoUrl} alt="Professional portrait of Ken Tegio Cada" className="h-40 w-40 rounded-full border border-[#E8D5A8]/60 object-cover object-top sm:h-48 sm:w-48" />
            </div>

            <p className="mt-7 text-[11px] font-extrabold uppercase tracking-[.24em] text-[#E8D5A8]">Virtual Assistant · Customer Support · Appointment Setter · Admin Support</p>
            <h1 className="mx-auto mt-4 max-w-4xl text-[clamp(2.9rem,9vw,5.6rem)] text-white">KEN TEGIO<br />CADA</h1>
            <div className="gold-rule gold-rule-center mt-6" aria-hidden="true" />
            <p className="mx-auto mt-6 max-w-2xl text-lg leading-relaxed text-white/80 sm:text-xl">The dependable VA behind cleaner calendars, fuller schedules, and calmer operations. I help US business owners save time, book more jobs, and keep every detail handled.</p>

            <div className="mt-8 flex flex-wrap justify-center gap-3">
              <a href="https://wa.me/639951404758" target="_blank" rel="noopener" className="inline-flex items-center gap-2 rounded-full bg-[#C6A664] px-5 py-3.5 font-extrabold text-[#0A1628]"><MessageCircle size={19} /> Contact via WhatsApp</a>
              <a href="mailto:ken_cada@yahoo.com" className="inline-flex items-center gap-2 rounded-full border border-white/40 bg-white/10 px-5 py-3.5 font-extrabold text-white"><Mail size={19} /> ken_cada@yahoo.com</a>
            </div>
            <div className="mt-7 flex flex-wrap justify-center gap-x-6 gap-y-2 text-sm text-white/80"><span className="flex items-center gap-2"><BadgeCheck size={17} className="text-[#C6A664]" /> 3+ years BPO + VA experience</span><span className="flex items-center gap-2"><ShieldCheck size={17} className="text-[#C6A664]" /> QA-focused · Detail-obsessed</span></div>

            {/* Stats — navy boxes, gold numbers */}
            <div className="mt-12 grid gap-4 text-left sm:grid-cols-2 lg:grid-cols-4">
              {stats.map((s) => (
                <div key={s.label} className="rounded-[22px] border border-white/10 bg-[#13294B] p-5">
                  <div className="h-1 w-8 rounded-full bg-[#C6A664]" aria-hidden="true" />
                  <p className="mt-4 text-[clamp(2rem,4vw,2.6rem)] font-extrabold leading-none text-[#C6A664]">{s.value}</p>
                  <p className="mt-2 text-sm leading-relaxed text-white/80">{s.label}</p>
                </div>
              ))}
            </div>
            <div className="mx-auto mt-8 max-w-3xl rounded-2xl border border-[#C6A664]/30 bg-white/5 px-5 py-4 text-left sm:text-center">
              <p className="text-[15px] font-bold leading-relaxed text-white">“I take ownership of the work — so you can focus on running the business.”</p>
              <p className="mt-2 text-[11px] font-extrabold uppercase tracking-[.18em] text-[#C6A664]">— Ken Tegio Cada</p>
            </div>
          </div>
        </section>

        {/* ABOUT */}
        <section id="about" className="paper-texture bg-[var(--paper)]">
          <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6 lg:py-24">
            <div className="grid gap-10 lg:grid-cols-[1.15fr_.85fr] lg:gap-14">
              <div>
                <SectionHeading eyebrow="About Ken" title="High-volume discipline. Quiet, reliable execution." />
                <p className="mt-6 text-lg leading-relaxed text-[var(--muted)]">I’m Ken Tegio Cada, a virtual assistant based in the Philippines supporting US clients. My background combines three years in BPO customer support with hands-on VA work for a US cleaning company — so I bring both the pace of a call center and the care of a trusted operations partner.</p>
                <p className="mt-4 leading-relaxed text-[var(--muted)]">I know what it takes to keep a business moving: answer customers well, follow up every time, keep the CRM clean, and make sure nothing important gets missed. My job is to give you back time — and give your customers a better experience.</p>
              </div>
              <div className="grid content-start gap-5">
                <div className="rounded-[24px] border border-[var(--line)] bg-[var(--surface)] p-6 card-shadow"><span className="grid h-11 w-11 place-items-center rounded-xl bg-[#E6F4F2] text-[#0E9A8B]"><Headset size={20} /></span><h3 className="mt-4 text-xl">Calm under volume</h3><p className="mt-2 text-sm leading-relaxed text-[var(--muted)]">Hundreds of calls and leads each week taught me to stay organized, patient, and accurate — even on the busiest days.</p></div>
                <div className="rounded-[24px] bg-[#0A1628] p-6 text-white card-shadow"><span className="grid h-11 w-11 place-items-center rounded-xl bg-[#13294B] text-[#C6A664]"><CalendarCheck size={20} /></span><h3 className="mt-4 text-xl text-white">Built for bookings</h3><p className="mt-2 text-sm leading-relaxed text-white/75">From cold outreach to confirmed appointments, I keep your pipeline active and your calendar working for you.</p></div>
              </div>
            </div>
          </div>
        </section>

        {/* EXPERIENCE */}
        <section id="experience" className="bg-[var(--surface)]">
          <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6 lg:py-24">
            <SectionHeading eyebrow="Experience" title="Work that earns trust." blurb="Real roles, real volume, real responsibility — across support, sales outreach, and day-to-day business operations." />
            <div className="mt-12 space-y-6">
              {experiences.map((job, i) => (
                <article key={job.role} className="premium-card grid gap-6 rounded-[28px] border border-[var(--line)] bg-white p-6 sm:p-8 lg:grid-cols-[220px_1fr]">
                  <div><span className="inline-flex h-11 w-11 items-center justify-center rounded-full bg-[#F1F4F8] font-extrabold text-[#0A1628]">0{i + 1}</span><p className="mt-4 text-sm font-extrabold uppercase tracking-wider text-[var(--gold-dark)]">{job.meta}</p></div>
                  <div><h3 className="text-2xl leading-tight text-[#0A1628] sm:text-3xl">{job.role}</h3><p className="mt-2 font-bold text-[#0E9A8B]">{job.company}</p><p className="mt-3 leading-relaxed text-[var(--muted)]">{job.summary}</p><ul className="mt-5 grid gap-3 sm:grid-cols-2">{job.points.map((p) => <li key={p} className="flex gap-2 text-sm leading-relaxed"><CheckCircle2 size={18} className="mt-0.5 shrink-0 text-[#0E9A8B]" />{p}</li>)}</ul></div>
                </article>
              ))}
            </div>
          </div>
        </section>

        {/* SERVICES */}
        <section id="services" className="bg-[var(--paper)]">
          <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6 lg:py-24">
            <SectionHeading eyebrow="Services" title="What I can take off your plate." blurb="Choose a service to see exactly how it works — and what stays handled for you." />
            <div className="mt-12 grid gap-5 lg:grid-cols-[1fr_1.1fr]">
              <div className="flex flex-col gap-4">{services.map((s, i) => <button key={s.title} onClick={() => setService(i)} aria-pressed={service === i} className={`flex items-center justify-between rounded-2xl border border-[var(--line)] bg-[var(--surface)] px-5 py-5 text-left transition ${service === i ? 'service-active bg-white' : 'hover:bg-white'}`}><span className="flex items-center gap-3"><span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-[#0A1628] text-lg text-[#C6A664]">{s.icon}</span><span className="font-extrabold text-[#0A1628]">{s.title}</span></span><ArrowUpRight size={19} className={service === i ? 'text-[#C6A664]' : 'text-[var(--muted)]'} /></button>)}</div>
              <div className="rounded-[28px] border border-[var(--line)] bg-white p-6 text-[var(--ink)] card-shadow sm:p-8"><p className="text-xs font-extrabold uppercase tracking-[.18em] text-[#0E9A8B]">Service focus · {service + 1} of 5</p><h3 className="mt-4 text-3xl text-[#0A1628]">{services[service].title}</h3><div className="gold-rule mt-5" aria-hidden="true" /><p className="mt-5 leading-relaxed text-[var(--muted)]">{services[service].desc}</p><ul className="mt-6 space-y-3">{services[service].points.map((p) => <li key={p} className="flex items-center gap-2.5 font-bold"><span className="h-2 w-2 shrink-0 rounded-full bg-[#C6A664]" />{p}</li>)}</ul><a href="https://wa.me/639951404758" target="_blank" rel="noopener" className="mt-7 inline-flex items-center gap-2 rounded-full bg-[#0A1628] px-5 py-3 text-sm font-extrabold text-white">Ask about this service <ArrowUpRight size={17} /></a></div>
            </div>
          </div>
        </section>

        {/* TOOLS */}
        <section id="tools" className="bg-[var(--surface)]">
          <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6 lg:py-24">
            <SectionHeading eyebrow="Tools & platforms" title="Ready to plug in." blurb="No long learning curve. I already work in the tools US teams use every day — and I adapt quickly to yours." />
            <div className="mt-10 flex flex-wrap gap-2">{filters.map((f) => <button key={f} onClick={() => setToolFilter(f)} aria-pressed={toolFilter === f} className={`rounded-full px-4 py-2.5 text-sm font-bold ${toolFilter === f ? 'bg-[#0A1628] text-white' : 'border border-[var(--line)] bg-white text-[var(--ink)]'}`}>{f}</button>)}</div>
            <div className="mt-6 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">{visibleTools.map((t) => <div key={t.name} className="tool-pill rounded-2xl border border-[var(--line)] bg-white p-5"><span className="grid h-10 w-10 place-items-center rounded-xl bg-[#F1F4F8] text-[#9A7F3F]"><Wrench size={18} /></span><p className="mt-4 font-extrabold text-[#0A1628]">{t.name}</p><p className="mt-1 text-xs font-bold uppercase tracking-wider text-[var(--muted)]">{t.cat}</p></div>)}</div>
          </div>
        </section>

        {/* WHY */}
        <section id="why" className="bg-[var(--paper)]">
          <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6 lg:py-24">
            <SectionHeading eyebrow="Why hire Ken Tegio Cada" title="The VA you don’t have to chase." />
            <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
              {[{ icon: <PhoneCall size={20} />, title: 'Proven under pressure', desc: 'Three years handling financial and mortgage support at high volume — with QA standards that keep quality high.' }, { icon: <CalendarCheck size={20} />, title: 'Bookings that show up', desc: 'Consistent outreach, clear notes, and follow-up that turn leads into confirmed appointments.' }, { icon: <Sparkles size={20} />, title: 'Operations, cleaned up', desc: 'From CRM cleanup to SOPs, I create order you can actually see — and keep it that way.' }, { icon: <Users size={20} />, title: 'Easy to work with', desc: 'Clear communication, ownership, and follow-through. You’ll always know what’s done and what’s next.' }].map((r) => <article key={r.title} className="premium-card rounded-[24px] border border-[var(--line)] bg-[var(--surface)] p-6"><span className="grid h-11 w-11 place-items-center rounded-xl bg-[#0A1628] text-[#C6A664]">{r.icon}</span><h3 className="mt-5 text-xl text-[#0A1628]">{r.title}</h3><p className="mt-2 text-sm leading-relaxed text-[var(--muted)]">{r.desc}</p></article>)}
            </div>
          </div>
        </section>

        {/* CONTACT */}
        <footer className="bg-[#0A1628] text-white">
          <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6 lg:py-24">
            <div className="grid gap-10 lg:grid-cols-[1.35fr_.85fr] lg:gap-14">
              <div><p className="eyebrow text-[#E8D5A8]">Let’s work together</p><h2 className="mt-4 text-[clamp(2.4rem,6.5vw,4.3rem)] text-white">Ready to save time<br />and book more jobs?</h2><div className="gold-rule mt-6" aria-hidden="true" /><p className="mt-6 max-w-xl leading-relaxed text-white/75">Tell me what’s taking up your time. I’ll help you clear the backlog, organize the operations, and keep your business moving.</p><div className="mt-8 flex flex-wrap gap-3"><a href="https://wa.me/639951404758" target="_blank" rel="noopener" className="inline-flex items-center gap-2 rounded-full bg-[#C6A664] px-5 py-3.5 font-extrabold text-[#0A1628]"><MessageCircle size={19} /> WhatsApp +63 995 140 4758</a><a href="mailto:ken_cada@yahoo.com" className="inline-flex items-center gap-2 rounded-full border border-white/35 px-5 py-3.5 font-extrabold text-white"><Mail size={19} /> Email Ken Tegio Cada</a></div></div>
              <div className="rounded-[28px] bg-white p-6 text-[var(--ink)] sm:p-7"><p className="text-xs font-extrabold uppercase tracking-[.18em] text-[#0E9A8B]">Quick contact</p><p className="mt-3 text-2xl font-extrabold text-[#0A1628]">Ken Tegio Cada</p><p className="mt-1 text-sm font-bold text-[var(--muted)]">Virtual Assistant · Philippines</p><div className="gold-rule mt-5" aria-hidden="true" /><div className="mt-5 space-y-3 text-sm"><a href="https://wa.me/639951404758" target="_blank" rel="noopener" className="flex items-center gap-3 rounded-xl bg-[var(--surface)] p-3.5 font-bold text-[#0A1628] hover:bg-[#E6F4F2]"><PhoneCall size={18} className="shrink-0 text-[#0E9A8B]" /> +63 995 140 4758</a><a href="mailto:ken_cada@yahoo.com" className="flex min-w-0 items-center gap-3 rounded-xl bg-[var(--surface)] p-3.5 font-bold text-[#0A1628] hover:bg-[#E6F4F2]"><Mail size={18} className="shrink-0 text-[#0E9A8B]" /><span className="break-all">ken_cada@yahoo.com</span></a><span className="flex items-center gap-3 rounded-xl bg-[var(--surface)] p-3.5 font-bold text-[#0A1628]"><MapPin size={18} className="shrink-0 text-[#0E9A8B]" /> Philippines · Remote US Clients</span></div><p className="mt-5 flex items-center gap-1.5 text-xs font-bold text-[var(--muted)]"><Star size={14} className="fill-[#C6A664] text-[#C6A664]" /> Trusted · Responsive · Detail-obsessed</p></div>
            </div>
            <div className="mt-12 flex flex-wrap items-center justify-between gap-3 border-t border-[#C6A664]/25 pt-6 text-xs text-white/70"><span>© {new Date().getFullYear()} Ken Tegio Cada · Virtual Assistant</span><span>Customer Support · Appointment Setting · Admin Support</span></div>
          </div>
        </footer>
      </main>
    </div>
  );
}

export default App;
